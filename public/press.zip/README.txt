Mohammad Abir Abbas — Press Kit
====================================

Updated: August 2026
Use: editorial, press, podcast hosts, partnerships.

What's inside
-------------
brand-onepager.pdf         — single-page brand summary
CV.pdf                     — full curriculum vitae
smartswap-whitepaper.pdf   — MIT Hacknation 2026 project write-up
portraits/                 — official headshots
logos/                     — co-founder brand assets
project-tiles/             — editorial tiles from the portfolio grid

Headshot usage
--------------
- portrait-2026.webp is the current 2026 headshot. Use this by default.
- portrait-bento.webp is the older bento landing portrait.
- For minimum-size crops, use the image at native resolution; do not upscale.

Boilerplate
-----------
Mohammad Abir Abbas is a Creative Technologist and AI Architect
based in Dubai. He is the AI Solution Architect at Famous Abaya LLC,
where he built the AbaYa-Track Delivery Module that recovered
AED 111K of trapped manufacturing backlog in 30 days (11.1:1
value-to-cost). In 2026 he won Next Top Project at MIT Hacknation
with SmartSwap. He is currently Chief Technical Advisor at Wavelink
and the co-founder of Deep Blue Digital.

Contact
-------
abir.abbas@proton.me
+971 054 361 8066
linkedin.com/in/abir-abbas
abir.getwaved.ai
youtube.com/@wavelinkd
